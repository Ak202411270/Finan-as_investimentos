<?php
session_start();
require_once 'config.php';
require_once 'Brapi.php'; // Inclui suporte à Brapi

/**
 * Busca o preço de ações, criptomoedas ou fundos via API.
 * Retorna float (>0) ou false em erro.
 */
function buscarPrecoAtivo($ticker, $tipo) {
    if ($tipo === 'Fundos') {
        return buscarPrecoBrapi($ticker); // Fundos via Brapi
    }

    $apiKey = API_KEY;
    $tickerEncoded = urlencode($ticker);

    if ($tipo === 'Ações' && str_ends_with($ticker, '.SA')) {
        $url = "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={$tickerEncoded}&apikey={$apiKey}";
    } elseif ($tipo === 'Criptomoedas') {
        // Ex.: BTC → busca cotação BTC/BRL
        $url = "https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency={$tickerEncoded}&to_currency=BRL&apikey={$apiKey}";
    } else {
        return false;
    }

    $response = @file_get_contents($url);
    if (!$response) {
        return false;
    }

    $data = json_decode($response, true);

    if (isset($data["Global Quote"])) {
        return floatval($data["Global Quote"]["05. price"] ?? 0);
    }

    if (isset($data["Realtime Currency Exchange Rate"])) {
        return floatval($data["Realtime Currency Exchange Rate"]["5. Exchange Rate"] ?? 0);
    }

    return false;
}

/**
 * Retorna a taxa anual (%) para cada “nome” de renda fixa.
 * Se não encontrar, devolve false.
 */
function valorFixoRenda($nomeTicker) {
    $tabela = [
        'SELIC'          => 10.50,  // Exemplo: 10,50% a.a. para Tesouro Selic
        'IPCA'           => 4.23,   // Exemplo: 4,23% (juro real de IPCA+)
        'TesouroDireto'  => 11.75   // Exemplo: 11,75% a.a. para Tesouro Prefixado
    ];
    return $tabela[$nomeTicker] ?? false;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) Lê valores do formulário:
    $nome_ticker = htmlspecialchars(trim($_POST['ticker'] ?? ''));
    $tipo        = htmlspecialchars(trim($_POST['classe'] ?? ''));
    // O campo 'principal' só virá no POST se a classe for "Renda Fixa"
    $principal   = floatval($_POST['principal'] ?? 0);

    // 2) Validação básica:
    if (empty($nome_ticker) || empty($tipo)) {
        $error = "Por favor, selecione a classe e o ativo.";
    } else {
        if ($tipo === 'Renda Fixa') {
            // Nesse caso, é obrigatório ter um principal > 0
            if ($principal <= 0) {
                $error = "Para Renda Fixa, informe o valor investido em reais (R\$).";
            } else {
                // Verifica se o “nome” é válido (tem taxa associada)
                $taxaPercentual = valorFixoRenda($nome_ticker);
                if ($taxaPercentual === false) {
                    $error = "Não foi possível reconhecer a taxa de renda fixa para “{$nome_ticker}”.";
                } else {
                    // Prepara para gravar: vamos salvar $principal no banco (e não a taxa)
                    $valorParaGravar = $principal;
                }
            }
        } else {
            // Ações / Criptomoedas / Fundos: NÃO pedimos o principal no formulário.
            // Buscamos o preço de mercado hoje (ou retornamos erro se não achar):
            $cotacao = buscarPrecoAtivo($nome_ticker, $tipo);
            if ($cotacao === false || $cotacao <= 0) {
                $error = "Não foi possível obter o preço de mercado do ativo “{$nome_ticker}”.";
            } else {
                // Aqui gravamos no banco o preço de mercado
                $valorParaGravar = $cotacao;
            }
        }
    }

    // 3) Se não houver erro, insere no banco:
    if (empty($error)) {
        $stmt = $conn->prepare("
            INSERT INTO investimentos (usuario_id, nome, tipo, valor, data)
            VALUES (?, ?, ?, ?, ?)
        ");
        $data_cadastro = date('Y-m-d');
        $stmt->bind_param(
            "issds",
            $_SESSION['usuario_id'],
            $nome_ticker,
            $tipo,
            $valorParaGravar,
            $data_cadastro
        );
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $success = "✅ Investimento cadastrado com sucesso!";
        } else {
            $error = "Erro ao cadastrar o investimento no banco de dados.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Novo Investimento</title>
  <style>
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    body {
      background-image: url('imagens/fds.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #f5f5f5;
      display: flex;
      align-items: center;
      justify-content: flex-start; /* alinha à esquerda */
    }

    .container {
      background-color: rgba(30, 30, 30, 0.95);
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.5);
      width: 600px;
      margin-left: 5vw; /* move um pouco para a esquerda */
    }

    h1 {
      text-align: center;
      color: #ffffff;
    }

    .alert {
      padding: 1em;
      border-radius: 4px;
      margin-bottom: 1em;
    }

    .error   { background: #3a1e1e; color: #ff6666; }
    .success { background: #1e3a1e; color: #66ff66; }

    form {
      display: grid;
      gap: .75em;
      background-color: rgba(44, 44, 44, 0.9);
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(255,255,255,0.1);
    }

    label {
      font-weight: bold;
      margin-bottom: 0.3em;
    }

    input, select, button {
      padding: 10px;
      border: none;
      border-radius: 6px;
      background-color: #1e1e1e;
      color: #f5f5f5;
      font-size: 1em;
    }

    input:focus, select:focus {
      outline: 2px solid #00bcd4;
    }

    button {
      background-color: #000;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #333;
    }

    #principalContainer {
      display: none;
    }

    a {
      display: block;
      margin-top: 20px;
      text-align: center;
      color: #00bcd4;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Adicionar Investimento</h1>

    <?php if ($error): ?>
      <div class="alert error"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="alert success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" action="novo_investimento.php">
      <label for="classe">Classe de Ativo:</label>
      <select name="classe" id="classe" required>
        <option value="">-- selecione uma classe --</option>
        <option value="Ações">Ações</option>
        <option value="Criptomoedas">Criptomoedas</option>
        <option value="Renda Fixa">Renda Fixa</option>
        <option value="Fundos">Fundos</option>
      </select>

      <label for="ticker">Ativo:</label>
      <select name="ticker" id="ticker" required disabled>
        <option value="">-- escolha a classe primeiro --</option>
      </select>

      <div id="principalContainer">
        <label for="principal">Valor Investido (R$):</label>
        <input
          type="number"
          id="principal"
          name="principal"
          step="0.01"
          min="0.01"
          placeholder="Digite o valor em reais"
        >
      </div>

      <button type="submit">Cadastrar</button>
    </form>

    <a href="painel.php">← Voltar ao Painel</a>
  </div>

  <script>
    const ativosPorClasse = {
      'Ações': [
        { val: 'PETR4.SA', txt: 'PETR4 (Petrobras ON)' },
        { val: 'VALE3.SA', txt: 'VALE3 (Vale ON)' },
        { val: 'ITUB4.SA', txt: 'ITUB4 (Itaú PN)' },
        { val: 'BBAS3.SA', txt: 'BBAS3 (Banco do Brasil ON)' },
        { val: 'BBDC4.SA', txt: 'BBDC4 (Bradesco PN)' },
        { val: 'ABEV3.SA', txt: 'ABEV3 (Ambev ON)' },
        { val: 'LREN3.SA', txt: 'LREN3 (Lojas Renner ON)' },
        { val: 'MGLU3.SA', txt: 'MGLU3 (Magazine Luiza ON)' },
        { val: 'B3SA3.SA', txt: 'B3SA3 (B3 ON)' },
        { val: 'WEGE3.SA', txt: 'WEGE3 (Weg ON)' }
      ],
      'Renda Fixa': [
        { val: 'SELIC', txt: 'SELIC (taxa básica de juros)' },
        { val: 'IPCA', txt: 'IPCA (juro real)' },
        { val: 'TesouroDireto', txt: 'Tesouro Direto (prefixado)' }
      ],
      'Fundos': [
        { val: 'MXRF11', txt: 'Maxi Renda (MXRF11)' },
        { val: 'CPTS11', txt: 'Capitania Securities II (CPTS11)' },
        { val: 'HGLG11', txt: 'CSHG Logística (HGLG11)' },
        { val: 'KNRI11', txt: 'Kinea Renda Imobiliária (KNRI11)' },
        { val: 'BCFF11', txt: 'BTG Pactual Fundo de Fundos (BCFF11)' },
        { val: 'BOVA11', txt: 'iShares Ibovespa (BOVA11)' },
        { val: 'IVVB11', txt: 'iShares S&P 500 (IVVB11)' },
        { val: 'DIVO11', txt: 'It Now IDIV (DIVO11)' },
        { val: 'SMAL11', txt: 'iShares Small Cap (SMAL11)' },
        { val: 'HASH11', txt: 'Hashdex Nasdaq Crypto Index (HASH11)' }
      ]
    };

    const selectClasse = document.getElementById('classe');
    const selectTicker = document.getElementById('ticker');
    const principalContainer = document.getElementById('principalContainer');
    const inputPrincipal = document.getElementById('principal');

    selectClasse.addEventListener('change', () => {
      const classe = selectClasse.value;
      const lista = ativosPorClasse[classe] || [];

      selectTicker.innerHTML = '';
      if (lista.length) {
        selectTicker.disabled = false;
        selectTicker.appendChild(new Option('-- selecione um ativo --', ''));
        lista.forEach(item => {
          selectTicker.appendChild(new Option(item.txt, item.val));
        });
      } else {
        selectTicker.disabled = true;
        selectTicker.appendChild(new Option('-- escolha a classe primeiro --', ''));
      }

      if (classe === 'Renda Fixa') {
        principalContainer.style.display = 'block';
        inputPrincipal.required = true;
      } else {
        principalContainer.style.display = 'none';
        inputPrincipal.required = false;
        inputPrincipal.value = '';
      }
    });
  </script>
</body>
</html>