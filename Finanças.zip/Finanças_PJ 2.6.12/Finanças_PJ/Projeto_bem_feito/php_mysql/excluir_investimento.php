<?php
session_start();

// 1) garante a sessão
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Entrada.php");
    exit;
}

// 2) inclui quem cria a conexão e as configs
include 'login.php';    // define $conexao (mysqli)
include 'config.php';   // define API_KEY, TAXA_SELIC_ANUAL, etc.

// 3) executa o DELETE
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $usuario_id = $_SESSION['usuario_id'];

    $sql  = "DELETE FROM investimentos WHERE id = ? AND usuario_id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ii", $id, $usuario_id);
    $stmt->execute();
}

// 4) volta para o painel
header("Location: Areadeentrada.php");
exit;

