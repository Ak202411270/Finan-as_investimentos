<?php
session_start();
include 'login.php';    // define $conexao (mysqli)
include 'config.php';   // define API_KEY, TAXA_SELIC_ANUAL, etc.

require __DIR__ . '/AlphaVantage.php';
require __DIR__ . '/brapi.php';



if (isset($_GET['delete_id'])) {
    $id = (int) $_GET['delete_id'];
    $usuario_id = $_SESSION['usuario_id'] ?? 0;
    $stmt = $conexao->prepare("DELETE FROM investimentos WHERE id = ? AND usuario_id = ?");
    $stmt->bind_param("ii", $id, $usuario_id);
    $stmt->execute();
    // redireciona para limpar o GET e evitar re-execuções no F5
    header("Location: painel.php");
    exit;
}

// Resto do seu código de sessão, consulta e lista...

/**
 * Tenta ler do cache a cotação de $ticker (ex.: "ITUB4.SA").
 * Se existir registro e tiver sido obtido há menos de $ttlMinutos, retorna ['preco' => float, 'obtido_em' => DateTime].
 * Caso contrário, retorna false.
 */
function getCachedQuote(mysqli $conexao, string $ticker, int $ttlMinutos = 60) {
    $sql  = "SELECT preco, obtido_em FROM cotacoes_cache WHERE ticker = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $ticker);
    $stmt->execute();
    $stmt->bind_result($preco, $obtidoEmStr);

    if ($stmt->fetch()) {
        $stmt->close();
        $obtidoEm = new DateTime($obtidoEmStr);
        $agora    = new DateTime('now');
        $intervalo = $obtidoEm->diff($agora);
        $minutosDecorridos = ($intervalo->days * 24 * 60)
                           + ($intervalo->h * 60)
                           + $intervalo->i;
        if ($minutosDecorridos < $ttlMinutos) {
            return ['preco' => (float) $preco, 'obtido_em' => $obtidoEm];
        }
    } else {
        $stmt->close();
    }

    return false;
}

/**
 * Insere ou atualiza no cache a cotação de $ticker com o valor $preco.
 */
function setCachedQuote(mysqli $conexao, string $ticker, float $preco) {
    $agora = (new DateTime('now'))->format('Y-m-d H:i:s');
    $sql   = "
        INSERT INTO cotacoes_cache (ticker, preco, obtido_em)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE
            preco = VALUES(preco),
            obtido_em = VALUES(obtido_em)
    ";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sds", $ticker, $preco, $agora);
    $stmt->execute();
    $stmt->close();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Entrada.php");
    exit;
}

$usuario_id   = $_SESSION['usuario_id'];
$nome_usuario = $_SESSION['nome'];

// Busca todos os investimentos desse usuário
$sql  = "SELECT * FROM investimentos WHERE usuario_id = ?";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();
?>





<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel do Usuário</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            background-image: url('imagens/preto.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #f5f5f5;
            padding: 40px 60px;
        }

        /* Header com efeito frosted glass */
        header.top-header {
            background-color: rgba(0, 0, 0, 0.6);
            -webkit-backdrop-filter: blur(10px);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header.top-header h2,
        header.top-header h3 {
            font-size: 2em;
            margin: 0;
            color: #fff; /* Texto branco */
        }

        header.top-header h3 {
            font-size: 1.3em;
            margin-top: 5px;
        }

        .top-links {
            margin-top: 20px;
            display: flex;
            gap: 20px;
        }

        .btn-link {
            background-color: #000; /* fundo preto */
            color: #fff; /* texto branco */
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            box-shadow: 0 4px 8px rgba(255,255,255,0.2);
            transition: background-color 0.3s, transform 0.2s;
        }
        .btn-link:hover {
            background-color: #333; /* cinza escuro no hover */
            transform: scale(1.05);
        }

        .btn-link.sair {
            /* mesmo estilo preto, só muda a sombra no hover */
            box-shadow: 0 4px 8px rgba(255, 0, 0, 0.3);
        }
        .btn-link.sair:hover {
            background-color: #555;
        }

        /* Tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(255,255,255,0.1);
            background-color: rgba(44, 44, 44, 0.9);
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 40px;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #000;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: rgba(58, 58, 58, 0.8);
        }
        tr:nth-child(odd) {
            background-color: rgba(44, 44, 44, 0.8);
        }

        td a {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            background-color: #000;
            color: #fff;
            margin: 2px;
        }
        td a:hover {
            background-color: #333;
        }

        .no-investments {
            text-align: center;
            margin-top: 40px;
            font-style: italic;
            color: #aaa;
            width: 100%;
        }
    </style>
</head>
<body>

    <header class="top-header">
      <h2>👋 Bem-vindo, <?= htmlspecialchars($nome_usuario) ?></h2>
      <h3>Seus Investimentos</h3>
      <div class="top-links">
        <a class="btn-link" href="novo_investimento.php">Cadastrar novo investimento</a>
        <a class="btn-link sair" href="logout.php">Sair</a>
      </div>
    </header>

    <?php if ($resultado->num_rows > 0): ?>
      <table>
        <tr>
          <th>Nome</th><th>Valor Compra (R$)</th><th>Tipo</th>
          <th>Data Compra</th><th>Cotação Atual (R$)</th>
          <th>Variação (R$)</th><th>Status</th><th>Ações</th>
        </tr>
        <?php while($row = $resultado->fetch_assoc()): ?>
        <?php
          $ticker = strtoupper(trim($row['nome']));
          $precoCompra = (float)$row['valor'];
          $tipoAtivo = trim($row['tipo']);
          $dataCompra = $row['data'];
          $cotacaoAtual = $precoCompra * 1.1;
          $absDiff = abs($cotacaoAtual - $precoCompra);
          $status = $cotacaoAtual > $precoCompra ? 'Valorizou' : ($cotacaoAtual < $precoCompra ? 'Desvalorizou' : 'Sem variação');
        ?>
        <tr>
          <td><?= htmlspecialchars($ticker) ?></td>
          <td><?= number_format($precoCompra,2,',','.') ?></td>
          <td><?= htmlspecialchars($tipoAtivo) ?></td>
          <td><?= date('d/m/Y', strtotime($dataCompra)) ?></td>
          <td><?= number_format($cotacaoAtual,2,',','.') ?></td>
          <td><?= number_format($absDiff,2,',','.') ?></td>
          <td><?= $status ?></td>
          <td>
            <a href="editar_investimento.php?id=<?= $row['id'] ?>">Editar</a>
            <a href="painel.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Tem certeza?')">Excluir</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p class="no-investments">Você ainda não cadastrou nenhum investimento.</p>
    <?php endif; ?>

</body>
</html>