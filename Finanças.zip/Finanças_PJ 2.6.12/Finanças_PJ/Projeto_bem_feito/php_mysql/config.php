<?php
// Chave e base da API EODHD:
define('EODHD_API_KEY',   '683c3d88a4dcc6.97449870');
define('EODHD_BASE_URL',  'https://eodhd.com/api');

// Chave para AlphaVantage (Ações/Cripto):
define('API_KEY',         '6XRK33YEYET3GBKJ');
define('ALPHA_VANTAGE_URL', 'https://www.alphavantage.co/query');
define('TAXA_SELIC_ANUAL', 13.75);
define('TAXA_IPCA_ANUAL', 4.23);       // exemplo: 4,23% a.a. (juro real do IPCA+)
define('TAXA_TD_PREFIXADO_ANUAL', 11.75); // exemplo: 11,75% a.a. (Tesouro Direto prefixado)


// Configura conexão MySQLi
$host     = "localhost";
$usuario  = "root";
$senha    = "";
$banco    = "usuario_investimento";
$conn     = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Exibe erros em modo dev
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

