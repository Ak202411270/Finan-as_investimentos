<?php
// AlphaVantage.php

class AlphaVantage {
    private $apiKey;
    private $baseUrl;

    public function __construct() {
        $this->apiKey  = API_KEY;
        $this->baseUrl = ALPHA_VANTAGE_URL;
    }

    /**
     * Busca o último preço de fechamento (close) disponível para um ticker.
     *
     * @param string $symbol Ex.: 'PETR4.SA'
     * @return float|null    Preço ou null em caso de erro
     */
    public function getLatestClose(string $symbol): ?float {
        $query = http_build_query([
            'function'   => 'TIME_SERIES_DAILY',
            'symbol'     => $symbol,
            'outputsize' => 'compact',
            'apikey'     => $this->apiKey
        ]);

        $ch = curl_init("{$this->baseUrl}?{$query}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $json = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($json, true);
        if (isset($data['Time Series (Daily)'])) {
            $series = $data['Time Series (Daily)'];
            $latest = array_key_first($series);
            return (float) $series[$latest]['4. close'];
        }

        return null;
    }
}
