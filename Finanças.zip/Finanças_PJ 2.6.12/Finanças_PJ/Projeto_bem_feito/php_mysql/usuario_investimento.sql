SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;




CREATE TABLE `investimentos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE cotacoes_cache (
  ticker VARCHAR(20) NOT NULL PRIMARY KEY,
  preco   DECIMAL(15,4) NOT NULL,
  obtido_em DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;








ALTER TABLE `investimentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`);


ALTER TABLE `investimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `investimentos`
  ADD CONSTRAINT `investimentos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);



  use usuario_investimento;

-- Tabela de Ações Padrão
CREATE TABLE IF NOT EXISTS acoes_padrao (
  codigo    VARCHAR(20)  NOT NULL PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Fundos Padrões
CREATE TABLE IF NOT EXISTS fundos_padroes (
  codigo    VARCHAR(20)  NOT NULL PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Renda Fixa (taxas padrão)


-- 2.1 Ações
INSERT IGNORE INTO acoes_padrao (codigo, descricao) VALUES
  ('PETR4.SA','PETR4 (Petrobras ON)'),
  ('VALE3.SA','VALE3 (Vale ON)'),
  ('ITUB4.SA','ITUB4 (Itaú PN)'),
  ('BBAS3.SA','BBAS3 (Banco do Brasil ON)'),
  ('BBDC4.SA','BBDC4 (Bradesco PN)'),
  ('ABEV3.SA','ABEV3 (Ambev ON)'),
  ('LREN3.SA','LREN3 (Lojas Renner ON)'),
  ('MGLU3.SA','MGLU3 (Magazine Luiza ON)'),
  ('B3SA3.SA','B3SA3 (B3 ON)'),
  ('WEGE3.SA','WEGE3 (Weg ON)');

-- 2.2 Fundos
INSERT IGNORE INTO fundos_padroes (codigo, descricao) VALUES
  ('MXRF11','Maxi Renda (MXRF11)'),
  ('CPTS11','Capitania Securities II (CPTS11)'),
  ('HGLG11','CSHG Logística (HGLG11)'),
  ('KNRI11','Kinea Renda Imobiliária (KNRI11)'),
  ('BCFF11','BTG Pactual Fundo de Fundos (BCFF11)'),
  ('BOVA11','iShares Ibovespa (BOVA11)'),
  ('IVVB11','iShares S&P 500 (IVVB11)'),
  ('DIVO11','It Now IDIV (DIVO11)'),
  ('SMAL11','iShares Small Cap (SMAL11)'),
  ('HASH11','Hashdex Nasdaq Crypto Index (HASH11)');

-- 2.3 Renda Fixa


ALTER TABLE investimentos ADD COLUMN porcentagem DECIMAL(5,2);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
