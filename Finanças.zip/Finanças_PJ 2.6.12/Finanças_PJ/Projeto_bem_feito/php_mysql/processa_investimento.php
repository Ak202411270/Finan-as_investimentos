<?php
session_start();
include 'login.php';
include 'config.php';        // define $conexao e as constantes TAXA_*
require 'investimento.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: Entrada.php");
    exit;
}

$usuario_id = (int) $_SESSION['usuario_id'];
$tipo       = $_POST['tipo'] ?? '';
$data       = $_POST['data'] ?? date('Y-m-d');

// Inicializa variáveis
$nome     = null;
$valor    = 0.0;
$tipo_taxa = null;

// Monta $nome, $valor e $tipo_taxa conforme o tipo de investimento
switch ($tipo) {
    case 'Ações':
        $nome  = trim($_POST['nome_acao'] ?? '');
        $valor = (float) ($_POST['valor'] ?? 0);
        break;

    case 'Fundos':
        $nome  = trim($_POST['nome_fundo'] ?? '');
        $valor = (float) ($_POST['valor'] ?? 0);
        break;

    case 'Renda Fixa':
        $tipo_taxa = $_POST['tipo_taxa'] ?? 'SELIC';
        // Define $valor a partir da constante correta
        if ($tipo_taxa === 'IPCA') {
            $valor = TAXA_IPCA_ANUAL;
        } elseif ($tipo_taxa === 'TD_PREFIXADO') {
            $valor = TAXA_TD_PREFIXADO_ANUAL;
        } else {
            $valor = TAXA_SELIC_ANUAL;
        }
        // nome fica nulo ou algo genérico, pois não há "ativo" para renda fixa
        $nome = null;
        break;

    default:
        // Tipo inválido
        header("Location: novo_investimento.php?error=tipo");
        exit;
}

// Instancia o modelo e executa o cadastro/edição
$inv = new Investimento($conexao);
// Supondo que cadastrar() trate tanto inserção quanto atualização,
// e aceite os cinco parâmetros: usuário, nome, valor, tipo, data e tipo_taxa opcional
$sucesso = $inv->cadastrar(
    $usuario_id,
    $nome,
    $valor,
    $tipo,
    $data,
    $tipo_taxa
);

if ($sucesso) {
    header("Location: painel.php");
    exit;
} else {
    header("Location: novo_investimento.php?error=gravar");
    exit;
}
