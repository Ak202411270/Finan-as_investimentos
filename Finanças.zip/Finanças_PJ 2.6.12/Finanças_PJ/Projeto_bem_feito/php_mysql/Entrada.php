<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro Minimalista</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Georgia', serif;
      background-color: #2f2f2f;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      display: flex;
      background-color: #000;
      color: white;
      max-width: 1200px;
      width: 90%;
      box-shadow: 0 0 40px rgba(0,0,0,0.4);
    }
    .form-box {
      flex: 1;
      padding: 80px 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .form-box h1 {
      font-size: 36px;
      margin-bottom: 24px;
    }
    .form-box p {
      font-size: 16px;
      line-height: 1.8;
      margin-bottom: 40px;
      color: #bfffe5;
    }
    label {
      font-size: 14px;
      margin-bottom: 8px;
      display: block;
    }
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 14px;
      margin-bottom: 24px;
      border: 1px solid #fff;
      background-color: transparent;
      color: #fff;
      font-size: 15px;
    }
    button {
      padding: 14px;
      width: 100%;
      background-color: #e5d9d1;
      color: #000;
      border: none;
      font-size: 15px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    button:hover {
      background-color: #d6cdc6;
    }
    .image-box {
      flex: 1;
      max-height: 100%;
      overflow: hidden;
    }
    .image-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    @media (max-width: 950px) {
      .container {
        flex-direction: column;
      }
      .image-box {
        height: 300px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="form-box">
      <h1>Cadastro</h1>
      <p>Domine suas finanças com clareza e propósito — pequenas escolhas hoje constroem grandes conquistas amanhã</p>
        <form action="processa_cadastro.php" method="post">
        <label for="nome">Nome de usuário:</label><br>
        <input type="text" name="nome" required><br><br>

        <label for="senha">Senha:</label><br>
        <input type="password" name="senha" required><br><br>

        <button type="submit">Cadastrar</button>
      </form>
    </div>
    <div class="image-box">
      <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e" alt="Deserto">
    </div>
  </div>
</body>
</html>