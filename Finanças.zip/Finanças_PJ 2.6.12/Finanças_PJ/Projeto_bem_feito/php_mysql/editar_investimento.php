<?php
session_start();
include 'login.php';
include 'config.php';  // define $conexao e as constantes TAXA_*
require 'investimento.php';
require_once 'brapi.php';
// 1) Autenticação
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Entrada.php");
    exit;
}
$usuario_id = (int) $_SESSION['usuario_id'];

// 2) Se for POST, processa a edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id   = (int) $_POST['id'];
    $tipo = $_POST['tipo'];

    // Renda Fixa: só atualiza valor conforme taxa escolhida
   if ($tipo === 'Renda Fixa') {
    // 1) valor que o usuário digitou
    $valorInvestido = (float) $_POST['valor'];

    // 2) taxa anual fixa (constante em config.php)
    $porcentagem = (float) TAXA_SELIC_ANUAL;

    // 3) atualiza valor + porcentagem
    $stmt = $conexao->prepare(
        "UPDATE investimentos
           SET valor       = ?,
               porcentagem = ?
         WHERE id           = ?
           AND usuario_id  = ?"
    );
    $stmt->bind_param("ddii",
        $valorInvestido,
        $porcentagem,
        $id,
        $usuario_id
    );
}
 else {
        // Ações ou Fundos: nome + valor manual
        // Obtém valor atualizado via API
        include_once 'config.php';
      $ticker = ($_POST['tipo'] === 'Ações') ? $_POST['nome_acao'] : $_POST['nome_fundo'];
$valor = buscarPrecoBrapi($ticker);

// fallback se a API falhar
if ($valor === false) {
    $valor = (float) $_POST['valor'];
}
// fallback
        if ($tipo === 'Ações') {
            $nome = $_POST['nome_acao'];
        } else {
            $nome = $_POST['nome_fundo'];
        }
        $stmt = $conexao->prepare(
            "UPDATE investimentos
               SET nome = ?, valor = ?
             WHERE id = ? AND usuario_id = ?"
        );
        $stmt->bind_param("sdii", $nome, $valor, $id, $usuario_id);
    }

    $stmt->execute();
    header("Location: painel.php");
    exit;
}

// 3) Se for GET, busca o investimento
if (empty($_GET['id'])) {
    echo "ID de investimento não informado.";
    exit;
}
$id = (int) $_GET['id'];

$stmt = $conexao->prepare(
    "SELECT * FROM investimentos
     WHERE id = ? AND usuario_id = ?"
);
$stmt->bind_param("ii", $id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "Investimento não encontrado.";
    exit;
}
$investimento = $result->fetch_assoc();

// 4) Carrega tabelas de referência
// Ações
$acoes = [];
$stmt = $conexao->prepare("SELECT codigo, descricao FROM acoes_padrao");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $acoes[] = $row;
}

// Fundos
$fundos = [];
$stmt = $conexao->prepare("SELECT codigo, descricao FROM fundos_padroes");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $fundos[] = $row;
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Investimento</title>
</head>
<body>
    <h2>Editar Investimento</h2>

    <form method="post" action="editar_investimento.php">
        <input type="hidden" name="id" value="<?= htmlspecialchars($investimento['id']) ?>">
        <input type="hidden" name="tipo" value="<?= htmlspecialchars($investimento['tipo']) ?>">

        <label>Tipo:</label><br>
        <input type="text"
               value="<?= htmlspecialchars($investimento['tipo']) ?>"
               disabled><br><br>

        <?php if ($investimento['tipo'] === 'Ações'): ?>
            <label>Ações:</label><br>
            <select name="nome_acao" required>
                <?php foreach ($acoes as $a): ?>
                    <option value="<?= htmlspecialchars($a['codigo']) ?>"
                        <?= $a['codigo'] === $investimento['nome'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($a['descricao']) ?>
                    </option>
                <?php endforeach; ?>
            </select><br><br>

           

        <?php elseif ($investimento['tipo'] === 'Fundos'): ?>
            <label>Fundos:</label><br>
            <select name="nome_fundo" required>
                <?php foreach ($fundos as $f): ?>
                    <option value="<?= htmlspecialchars($f['codigo']) ?>"
                        <?= $f['codigo'] === $investimento['nome'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($f['descricao']) ?>
                    </option>
                <?php endforeach; ?>
            </select><br><br>

           

       <?php else: /* Renda Fixa com taxa estática */ ?>
    <label>Valor Investido (R$):</label><br>
    <input
        type="number"
        name="valor"
        step="0.01"
        value="<?= htmlspecialchars($investimento['valor']) ?>"
        required
    ><br><br>
<?php endif; ?>

      



        <button type="submit">Salvar alterações</button>
        <a href="painel.php">Cancelar</a>
    </form>
</body>
</html>
