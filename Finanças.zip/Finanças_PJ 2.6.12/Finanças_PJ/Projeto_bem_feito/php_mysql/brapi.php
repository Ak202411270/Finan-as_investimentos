<?php
// Chave da API da Brapi
define('BRAPI_KEY', 'ghKkBB2KHNGCjinn7kJB3P');

// Função para buscar o preço de um fundo (FIIs ou ETFs)
function buscarPrecoBrapi($ticker) {
    $url = "https://brapi.dev/api/quote/" . urlencode($ticker);
    $headers = [
        "Authorization: Bearer " . BRAPI_KEY
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if (!$response) return false;

    $data = json_decode($response, true);
    if (isset($data['results'][0]['regularMarketPrice'])) {
        return floatval($data['results'][0]['regularMarketPrice']);
    }

    return false;
}


